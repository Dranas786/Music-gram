from http.client import HTTPResponse

from django.db import connection
from .serializers import *
from .models import *

from django.http import HttpResponse

from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status

from rest_framework.views import APIView
import json
# Create your views here.

# api for getting the user's liked musics

# to get the liked music of a user
# to update the liked music of a user


class EditPlayList(APIView):
    def get(self, request, playlist_id, song_id):
        songs = Contains.objects.filter(playlist_id=playlist_id)
        serializers = ContainsSerializer(songs, many=True)
        return Response(serializers.data)

    def post(self, request, playlist_id, song_id):
        serializer = ContainsSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, playlist_id, song_id):
        try:
            song = Contains.objects.filter(
                playlist_id=playlist_id).get(song_id=song_id)
        except Contains.DoesNotExist:
            return HTTPResponse(status=status.HTTP_404_NOT_FOUND)

        song.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


class UserPlaylists(APIView):
    def get(self, request, username, playlist_id):
        playlists = Playlist.objects.filter(username=username)
        serializer = PlaylistSerializer(playlists, many=True)
        return Response(serializer.data)

    def post(self, request, username, playlist_id):
        serializer = PlaylistSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_202_ACCEPTED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, username, playlist_id):
        # removing playlist from the PlayLists

        try:
            playlist = Playlist.objects.get(playlist_id=playlist_id)
        except Playlist.DoesNotExist:
            return HTTPResponse(status=status.HTTP_404_NOT_FOUND)
        playlist.delete()

        # removing all the songs in the playlist
        songs = Contains.objects.filter(playlist_id=playlist_id)
        for song in songs:
            song.delete()

        return Response(status=status.HTTP_204_NO_CONTENT)


class UserUnposts(APIView):
    def delete(self, request, username, song_id):
        try:
            post = Posts.objects.filter(username=username).get(song_id=song_id)
        except Posts.DoesNotExist:
            return HTTPResponse(status=status.HTTP_404_NOT_FOUND)

        post.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


class UserPosts(APIView):
    def get(self, request, username):
        posted_songs = Posts.objects.filter(username=username)
        serializer = PostsSerializer(posted_songs, many=True)
        return Response(serializer.data)

    def post(self, request, username):
        serializer = PostsSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_202_ACCEPTED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# need to wait till the models are here
class SongInfo(APIView):
    def get(self, request, song_id):
        try:
            song = Song.objects.get(pk=song_id)
            metadata = Metadata.objects.get(pk=song_id)
        except Song.DoesNotExist:
            return HTTPResponse(status=status.HTTP_404_NOT_FOUND)
        except Metadata.DoesNotExist:
            return HTTPResponse(status=status.HTTP_404_NOT_FOUND)

        song_serializer = SongSerializer(song)
        metadata_serializer = MetadataSerializer(metadata)

        obj = {
            "song": song_serializer.strip("[]"),
            "meta": metadata_serializer.strip("[]")
        }
        return Response(obj)

# class SongInfo(APIView):
#     def get_song(self, song_id):
#         try:
#             return Song.objects.get(song_id=song_id)
#         except Song.DoesNotExist:
#             return HTTPResponse(status=status.HTTP_404_NOT_FOUND)

#     def get_metadata(self, song_id):
#         try:
#             return Metadata.objects.get(Song_id=song_id)
#         except Metadata.DoesNotExist:
#             return HTTPResponse(status=status.HTTP_404_NOT_FOUND)

#     def get(self, req, song_id):
#         song = self.get_song(song_id)
#         metadata = self.get_metadata(song_id)
#         serializer_song = SongSerializer(song)
#         serializer_metadata = MetadataSerializer(metadata)

#         obj = {
#             "song": serializer_song.strip("[]"),
#             "meta": serializer_metadata.strip("[]")
#         }
#         return Response(obj).json()


class UserUnlikeMusic(APIView):
    def Delete(self, request, username, song_id):
        try:
            likedmusic = Likes.object.filter(
                username=username).get(song_id=song_id)
        except Likes.DoesNotExist:
            return HTTPResponse(status=status.HTTP_404_NOT_FOUND)

        likedmusic.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


class UserLikedMusic(APIView):
    def get_liked_music(self, username):
        return Likes.objects.filter(username=username)

    def get(self, request, username):
        likedmusic = self.get_liked_music(username)
        serializer = LikesSerializer(likedmusic, many=True)
        return Response(serializer.data)

    def post(self, request, username):
        serializer = LikesSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_202_ACCEPTED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# Using the classes for the apis
# this class does the same thing as the def user_list()


class UserAPIView(APIView):

    def get(self, request):
        # gets all the objects in the User relation
        users = User.objects.all()
        # converts all the objects to something python understands(dictionary)
        serializer = UserSerializer(users, many=True)
        # converts the dictionary into JSON and then send that as a response to the request
        # return JsonResponse(serializer.data, safe=False)
        # if you are using decorators and Response then you dont need the JSONResponse
        return Response(serializer.data)

    def post(self, request):
        # parses the JSON
        # data = JSONParser().parse(request)
        # dont need Parser when using decorators

        # serializes the parsed data into dictionary that python understands?
        # serializer = UserSerializer(data=data)
        # since we not using the parser. The decorators automatically Parse the json info?
        serializer = UserSerializer(data=request.data)

        # If the serialized data is valid we save it otherwise return JSON response with error
        if(serializer.is_valid()):
            serializer.save()
            # return JsonResponse(serializer.data, status=201)
            # using Response from rest_framework
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        # return JsonResponse(serializer.errors, status=400)
        # using Response from rest_framework
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

# api view class for the function user_detail


class UserDetail(APIView):
    def get_user(self, username):
        try:
            return User.objects.get(pk=username)
        except User.DoesNotExist:
            return HTTPResponse(status=status.HTTP_404_NOT_FOUND)

    def get(self, req, pk):
        user = self.get_user(pk)
        serializer = UserSerializer(user)
        return Response(serializer.data)

    def put(self, req, pk):
        user = self.get_user(pk)
        serializer = UserSerializer(user, data=req.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, req, pk):
        user = self.get_user(pk)
        user.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


class ProducerDetail(APIView):
    def get_producer(self, producer_id):
        try:
            return Producer.objects.get(producer_id=producer_id)
        except Producer.DoesNotExist:
            return HTTPResponse(status=status.HTTP_404_NOT_FOUND)

    def get(self, req, producer_id):
        producer = self.get_producer(producer_id)
        serializer = ProducerSerializer(producer)
        return Response(serializer.data)

    def put(self, req, producer_id):
        producer = self.get_producer(producer_id)
        serializer = ProducerSerializer(producer, data=req.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, req, producer_id):
        producer = self.get_producer(producer_id)
        producer.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


@api_view(["GET", "POST"])
def user_list(request):
    if request.method == "GET":
        # gets all the objects in the User relation
        users = User.objects.all()
        # converts all the objects to something python understands(dictionary)
        serializer = UserSerializer(users, many=True)
        # converts the dictionary into JSON and then send that as a response to the request
        # return JsonResponse(serializer.data, safe=False)
        # if you are using decorators and Response then you dont need the JSONResponse
        return Response(serializer.data)

    elif request.method == "POST":
        # parses the JSON
        # data = JSONParser().parse(request)
        # dont need Parser when using decorators

        # serializes the parsed data into dictionary that python understands?
        # serializer = UserSerializer(data=data)
        # since we not using the parser. The decorators automatically Parse the json info?
        serializer = UserSerializer(data=request.data)

        # If the serialized data is valid we save it otherwise return JSON response with error
        if(serializer.is_valid()):
            serializer.save()
            # return JsonResponse(serializer.data, status=201)
            # using Response from rest_framework
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        # return JsonResponse(serializer.errors, status=400)
        # using Response from rest_framework
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(["GET", "PUT", "DELETE"])
def user_detail(request, pk):
    try:
        # gets the user with primary key =pk
        user = User.objects.get(pk=pk)
    except User.DoesNotExist:
        return HttpResponse(status=status.HTTP_404_NOT_FOUND)

    if request.method == "GET":
        serializer = UserSerializer(user)
        return Response(serializer.data)

    # updating an already existing User tuple
    elif request.method == "PUT":
        # data = JSONParser().parse(request)
        serializer = UserSerializer(user, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    # deleting an already existing User tuple
    elif request.method == "DELETE":
        user.delete()
        return HTTPResponse(status=status.HTTP_204_NO_CONTENT)
